const express = require("express");
const cors = require('cors');
const path = require('path');
const app = express();
const port = 3000;

app.use(cors());

// URL for your prediction API
const url = "http://127.0.0.1:5000/predict";

// Setting up view engine and views directory
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware to parse incoming requests
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));


// Data to be used in the form
const data = ["Rainfall", "Sunshine", "WindGustSpeed", "Humidity9am", "Humidity3pm", "Pressure9am", "Pressure3pm", "Cloud9am", "Cloud3pm", "Temp9am", "Temp3pm", "RainToday"];

// Route to render the form
app.get("/", (req, res) => {
    res.render('index', { data });
});

// Route to handle form submission
app.post("/submit", async (req, res) => {
    const ob = req.body;
    const obj = {};
    for (const [key, value] of Object.entries(ob)) {
        if (key !== "type") obj[String(key)] = Number(value);
        else obj[String(key)] = value;
    }
    console.log(obj);
    let re = -1;
    try {
        const response = await fetch(url, {
            method: "post",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(obj),
        });
        const data = await response.json();
        re = Number(data["prediction"]);
        console.log(re);
    } catch (err) {
        console.log(err);
    }
    res.render('predict', { re });
});

app.listen(port, () => {
    console.log(`Listening on port ${port}`);
});
